import './App.css';
import Navigation from './components/Navigation.js';
import React from 'react';
import { BrowserRouter as Router , Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import HomePageFirstTimer from './pages/HomePageFirstTimer';
import AddRestaurantPage from './pages/AddRestaurantPage';
import RandomRestaurantPage from './pages/RandomRestaurantPage';
import Settings from './pages/Settings';

function App() {

  return (
    <>
    <div className="App">
      <Router>
        <div className="App-header">
          <Routes>
            <Route path="/" element={<HomePage />}/>
            <Route path="/first-timer" element={<HomePageFirstTimer />}/>
            <Route path="/add-restaurant" element={<AddRestaurantPage />}/>
            <Route path="/random-restaurant" element={<RandomRestaurantPage />}/>
            <Route path="/settings" element={<Settings />}/>
          </Routes>
        </div>
      </Router>
    </div>
    </>
  );
}

export default App;
