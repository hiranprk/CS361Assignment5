import React, { Component } from "react";
import styled, { css } from "styled-components";
import { Link } from "react-router-dom";
import AddIcon from "../components/AddIcon.js";
import SettingIcon from "../components/SettingIcon.js";
import BigButton from "../components/BigButton.js";
import ListIcon from "../components/ListIcon.js";

function HomePage(props) {
  return (
    <>    
      <Rect3Row>
        <Link to='/add-restaurant'>
          <AddIcon></AddIcon>
        </Link>
        <AddRestaurant>Add Restaurant</AddRestaurant>
      </Rect3Row>

      <RestroRandomStack>
        <RestroRandom>Restro Random</RestroRandom>
        <RestroRandom1>Outsource your decision to us!</RestroRandom1>
      </RestroRandomStack>

      <EllipseStack>
        <Link to='/random-restaurant'>
          <BigButton></BigButton>
          <IMHungry>I'M HUNGRY!!</IMHungry>
        </Link>
      </EllipseStack>
      
      <DropDown>
        <select name="unit">
        <option value="All lists">All Lists</option>
        <option value="Restuarant">Restaurant</option>
        <option value="Cafes">Cafes</option>
        <option value="Pubs & Bars">Pubs & Bar</option>
        </select>
      </DropDown>
      
      <RectRow>
        <input type="checkbox" id="test" name="fruit" value="apple"></input>
        <NewRestaurantOnly>New Restaurant Only!</NewRestaurantOnly>
      </RectRow>

      <Rect2Row>
        <input type="checkbox" id="test" name="fruit" value="apple"></input>
        <AiSuggest>AI Suggest!</AiSuggest>
      </Rect2Row>
      
      <Rect4Row>
        <Link to="/Settings">
          <ListIcon></ListIcon>
        </Link>
      </Rect4Row>

      
      
    </>
  );
}

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;

const IMHungry = styled.span`
  font-family: ;
  top: 125px;
  left: 45px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
`;

const EllipseStack = styled.div`
  width: 275px;
  height: 275px;
  margin-top: 50px;
  margin-left: 50px;
  position: relative;
`;

const Rect = styled.div`
  width: 28px;
  height: 28px;
  background-color: #E6E6E6;
`;

const DropDown = styled.span`
  font-family: ;
  font-style: normal;
  font-weight: 600;
`;

const NewRestaurantOnly = styled.span`
  font-family: ;
  font-style: normal;
  font-weight: 400;
  font-size: 22px;
  color: #121212;
  margin-left: 9px;
  margin-top: 0px;
`;

const RectRow = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  margin-top: 20px;
  margin-left: 108px;
  margin-right: 97px;
`;

const Rect2 = styled.div`
  width: 28px;
  height: 28px;
  background-color: #E6E6E6;
`;

const AiSuggest = styled.span`
font-family: ;
font-style: normal;
font-weight: 400;
font-size: 22px;
color: #121212;
margin-left: 9px;
margin-top: 0px;
`;

const Rect2Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  margin-top: 9px;
  margin-left: 108px;
  margin-right: 159px;
`;

const AddRestaurant = styled.span`
  font-family: ;
  font-style: normal;
  font-weight: 400;
  font-size: 22px;
  color: #121212;
  margin-left: 9px;
  margin-top: 0px;
`;

const Rect3Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  margin-top: 0px;
  margin-left: 29px;
  margin-right: 205px;
`;

const Rect4Row = styled.div`
  margin-top: 100px;
  margin-left: 231px;
  border: none;
`;

const RestroRandom = styled.span`
  font-family: ;
  top: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  text-align: center;
  font-size: 40px;
  left: 0px;
`;

const RestroRandom1 = styled.span`
  font-family: ;
  top: 46px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  text-align: center;
  font-size: 20px;
  left: 2px;
`;

const RestroRandomStack = styled.div`
  width: 274px;
  height: 70px;
  margin-top: 50px;
  margin-left: 51px;
  position: relative;
`;

export default HomePage;


//<Link to="/add-restaurant">Add new restro</Link>