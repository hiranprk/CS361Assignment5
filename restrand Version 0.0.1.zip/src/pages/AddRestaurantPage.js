import React, { useState } from 'react';
import styled, { css } from "styled-components";
import {Link} from 'react-router-dom';
import CloseIcon from "../components/CloseIcon.js"
import MaterialButtonPrimary from "../components/MaterialButtonPrimary";

function AddRestaurantPage() {
    const [name, setName] = useState('');

    return(
        <>
            <Rect1Row>
                <Link to="/">
                    <CloseIcon></CloseIcon>
                </Link>   
            </Rect1Row>
            
            <Rect2Row>
                <form>
                    <label>
                        Add New Restaurant:
                        <br></br>
                        <input type="text" value={name}
                        onChange={e => setName(e.target.value)} />
                    </label>

                    <br></br>
                    <br></br>
                    <>to </>
                    <DropDown>
                        <select name="unit">
                        <option value="Restuarant">Restaurant</option>
                        <option value="Cafes">Cafes</option>
                        <option value="Pubs & Bars">Pubs & Bar</option>
                        </select>
                    </DropDown>

                    <br></br>
                    <br></br>

                    <button onClick={e => {
                    alert(`${name} added to list`);
                    e.preventDefault();
                    }}>
                        <MaterialButtonPrimary
                            style={{
                                height: 36,
                                width: 100,
                                marginTop: 0,
                                alignSelf: "center"
                            }}
                        ></MaterialButtonPrimary>
                    </button>
                </form>
            </Rect2Row>
            
        </>
    );
}

const Rect1Row = styled.div`
    margin-top: -500px;
    margin-left: 700px;
`;

const Rect2Row = styled.div`
    
`;

const DropDown = styled.span`
  font-family: ;
  font-style: normal;
  font-weight: 600;
`;


export default AddRestaurantPage;