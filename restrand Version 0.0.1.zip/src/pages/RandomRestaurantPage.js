import React from 'react';
import styled, { css } from "styled-components";
import {Link} from 'react-router-dom';
import MapIcon from "../components/MapIcon.js"
import CloseIcon from "../components/CloseIcon.js"
import {PhoneIcon} from "../components/Arrows.js"

function RandomRestaurantPage() {
    const handleClick = () => {
        window.open('https://goo.gl/maps/J9mPS6Atgk2x1Ppt7')
    };
    
    const callThem = () => {
        alert('calling +6685283838')
    }
    
    return(
        <>
            <Rect1Row>
                <Link to="/">
                    <CloseIcon></CloseIcon>
                </Link>   
            </Rect1Row>

            <h2>Huradot Conburi by Nana Coffee Roaster</h2>
            <h3>30/10 Soi Natmonsewi Tumbol Samet Amphur Chonburi 20000</h3>

            <br></br>
            <Link onClick={handleClick}>
                <MapIcon></MapIcon>
                <br></br>
                Navigate There!
            </Link>

            <br></br>
            <Link onClick={callThem}>
                <PhoneIcon></PhoneIcon>
                <br></br>
                Call Them!
            </Link>
        </>
    );
}

const Rect1Row = styled.div`
    margin-top: -300px;
    margin-left: 700px;
`;

export default RandomRestaurantPage;