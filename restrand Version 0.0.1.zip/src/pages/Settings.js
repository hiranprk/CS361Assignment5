import React, { useState } from 'react';
import styled, { css } from "styled-components";
import {Link} from 'react-router-dom';
import DeleteIcon from '../components/DeleteIcon'
import CloseIcon from "../components/CloseIcon.js"
import MaterialButtonPrimary, { ImportButton } from "../components/MaterialButtonPrimary";

function Settings() {
    const [name, setName] = useState('');

    return(
        <>
            <Rect1Row>
                <Link to="/">
                    <CloseIcon></CloseIcon>
                </Link>   
            </Rect1Row>
            
            <Rect2Row>
                <form>
                    <label>
                        Add New List:
                        <br></br>
                        <input type="text" value={name}
                        onChange={e => setName(e.target.value)} />
                    </label>

                    <br></br>
                    <br></br>

                    <button onClick={e => {
                    alert(`${name} added`);
                    e.preventDefault();
                    }}>
                        <MaterialButtonPrimary
                            style={{
                                height: 36,
                                width: 100,
                                marginTop: 0,
                                alignSelf: "center"
                            }}
                        ></MaterialButtonPrimary>
                    </button>
                </form>
            </Rect2Row>

            <Rect3Row>
                <h2>Lists:</h2>
                <h3>Restaurants  < DeleteIcon /></h3>
                <h3>Cafes  < DeleteIcon /></h3>
                <h3>Pubs & Bars  < DeleteIcon /></h3>
                <button onClick={e => {
                    alert(`${name} added`);
                    e.preventDefault();
                    }}>
                        <ImportButton
                            style={{
                                height: 36,
                                width: 100,
                                marginTop: 0,
                                alignSelf: "center"
                            }}
                        ></ImportButton>
                    </button>
                <AdvancedOption> advanced option</AdvancedOption>
            </Rect3Row>
        </>
    );
}

const Rect1Row = styled.div`
    margin-top: 0px;
    margin-left: 700px;
`;

const Rect2Row = styled.div`
    
`;

const Rect3Row = styled.div`
    margin-top: 0px;
    margin-left: 0px;
`;

const DropDown = styled.span`
  font-family: ;
  font-style: normal;
  font-weight: 600;
`;

const AdvancedOption = styled.span`
    color: red;
    font-size: 20px;
    margin-top: 100px;
`;
export default Settings;