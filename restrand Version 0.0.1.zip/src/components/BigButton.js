import React from 'react';

function BigButton() {
    return(
        <svg
            viewBox="0 0 274.9 274.9"
            style={{
                left: 0,
                width: 275,
                height: 275,
                position: "absolute",
                top: 0
            }}
        >
            <ellipse
                stroke="rgba(78,153,229,1)"
                strokeWidth={13}
                fill="rgba(237,39,120,1)"
                cx={137}
                cy={137}
                rx={131}
                ry={131}
            ></ellipse>
            
        </svg>
    )
}

export default BigButton;
