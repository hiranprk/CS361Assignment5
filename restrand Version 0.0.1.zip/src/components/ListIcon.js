import React from 'react';
import { AiOutlineUnorderedList } from 'react-icons/ai';

function ListIcon() {
    return(
        <>
        <AiOutlineUnorderedList></AiOutlineUnorderedList>
        </>
    )
}

export default ListIcon;