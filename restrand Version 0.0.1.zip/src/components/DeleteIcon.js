import React from 'react';
import { MdDeleteForever } from 'react-icons/md';

function DeleteIcon() {
    return(
        <>
        <MdDeleteForever onClick={ () => alert("Are you sure you want to delete this list?")}></MdDeleteForever>
        </>
    )
}

export default DeleteIcon;