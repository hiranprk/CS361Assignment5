import React from 'react';
import { LiaMapMarkedAltSolid } from 'react-icons/lia';

function MapIcon() {
    return(
        <>
        <LiaMapMarkedAltSolid></LiaMapMarkedAltSolid>
        </>
    )
}

export default MapIcon;