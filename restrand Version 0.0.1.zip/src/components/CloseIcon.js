import React from 'react';
import { CgClose } from 'react-icons/cg';

function CloseIcon() {
    return(
        <>
        <CgClose></CgClose>
        </>
    )
}

export default CloseIcon;