import React from 'react';
import { AiFillSetting } from 'react-icons/ai';

function SettingIcon() {
    return(
        <>
        <AiFillSetting></AiFillSetting>
        </>
    )
}

export default SettingIcon;