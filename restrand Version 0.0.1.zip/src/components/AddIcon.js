import React from 'react';
import { CgAddR } from 'react-icons/cg';

function AddIcon() {
    return(
        <>
        <CgAddR></CgAddR>
        </>
    )
}

export default AddIcon;