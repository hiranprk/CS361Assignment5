import React from 'react';
import {Link} from 'react-router-dom';

function Navigation (){

    //uses <Link to=""></Link> instead of <a href=""></a> so that no request is going out to the server when links are clicked (no traffic).
    //must import Link from react-router-dom to use the <Link> element
    return (
        <nav>
            <Link to="/">Home</Link>
            <Link to="/random-restaurant">Hungry!!</Link>
            <Link to="/add-restaurant">Add new restro</Link>
        </nav>
    );
}

export default Navigation;