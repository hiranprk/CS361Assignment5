import React from 'react';
import { PiArrowBendDownLeftBold, PiArrowBendDownRightBold, PiArrowBendLeftDownBold, PiArrowBendLeftUpBold, 
    PiArrowBendRightDownBold, PiArrowBendRightUpBold, PiArrowBendUpLeftBold, PiArrowBendUpRightBold  } from 'react-icons/pi';
import {FiPhone} from 'react-icons/fi';

function ArrowDownLeft() {
    return(
        <>
        <PiArrowBendDownLeftBold/>
        </>
    )
}

function ArrowDownRight() {
    return(
        <>
        <PiArrowBendDownRightBold/>
        </>
    )
}
function ArrowLeftDown() {
    return(
        <>
        <PiArrowBendLeftDownBold/>
        </>
    )
}
function ArrowLeftUp() {
    return(
        <>
        <PiArrowBendLeftUpBold/>
        </>
    )
}
function ArrowRightDown() {
    return(
        <>
        <PiArrowBendRightDownBold/>
        </>
    )
}
function ArrowRightUp() {
    return(
        <>
        <PiArrowBendRightUpBold/>
        </>
    )
}
function ArrowUpLeft() {
    return(
        <>
        <PiArrowBendUpLeftBold/>
        </>
    )
}
function ArrowUpRight() {
    return(
        <>
        <PiArrowBendUpRightBold/>
        </>
    )
}

function PhoneIcon() {
    return(
        <>
        <FiPhone/>
        </>
    )
}

export {ArrowDownLeft, ArrowDownRight, ArrowLeftDown, ArrowRightDown, ArrowRightUp, ArrowUpLeft, ArrowUpRight, ArrowLeftUp, PhoneIcon};